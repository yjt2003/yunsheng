package com.yunsheng.bookController.utils;

import com.alibaba.fastjson.JSONObject;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;

public class Json {
    public static String getJson(HttpServletRequest request) throws IOException {
        InputStreamReader insr = new InputStreamReader(request.getInputStream(), StandardCharsets.UTF_8);
        StringBuilder str = new StringBuilder();
        int respInt = insr.read();
        while(respInt != -1){
            str.append((char)respInt);
            respInt = insr.read();
        }
        String json = str.toString();
        insr.close();
        return json;
    }
    public static void sendStatus(HttpServletResponse response,int status) throws IOException {
        PrintWriter out = response.getWriter();
        JSONObject object = new JSONObject();
        object.put("status",status);
        out.println(object);
    }

    public static void sendDataArr(HttpServletResponse response, Object arr) throws IOException {
        PrintWriter out = response.getWriter();
        String json = JSONObject.toJSONString(arr);
        out.println(json);
    }
}
