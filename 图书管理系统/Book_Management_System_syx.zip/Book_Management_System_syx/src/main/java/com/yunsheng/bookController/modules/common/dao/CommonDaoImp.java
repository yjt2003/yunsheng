package com.yunsheng.bookController.modules.common.dao;

import com.yunsheng.bookController.modules.common.entity.Book;
import com.yunsheng.bookController.modules.common.entity.BorrowRecords;
import com.yunsheng.bookController.utils.DBUtil;

import java.sql.*;
import java.util.ArrayList;

public class CommonDaoImp implements CommonDao {
    @Override
    public Book getBook(String name) throws Exception {
        Connection conn = DBUtil.connectMysql();
        String sql = "select * from book where name = ?";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setString(1,name);
        ResultSet rs = pstmt.executeQuery();
        rs.next();
        return new Book(rs.getString("name"), rs.getString("author"),
                rs.getString("ISBN"), rs.getString("readerID"),rs.getString("readerName"),
        rs.getString("borrowTime"),rs.getString("returnTime"));
    }
    public static ArrayList<Book> getBookAll() throws Exception {
        Connection conn = DBUtil.connectMysql();
        String sql = "select * from book";
        Statement st = conn.createStatement();
        ResultSet rs = st.executeQuery(sql);
        ArrayList<Book> bookArr = new ArrayList<Book>();
        while (rs.next()){
            bookArr.add(new Book(rs.getString("name"), rs.getString("author"),
                    rs.getString("ISBN"), rs.getString("readerID"),rs.getString("readerName"),
                    rs.getString("borrowTime"),
                    rs.getString("returnTime")));
        }
        return bookArr;
    }

    @Override
    public BorrowRecords getRecordPackaged(String bookName, String borrower, Timestamp borrowTime,int howLong,
                                           boolean returned,boolean destroyed,boolean compensated) {
        return new BorrowRecords(bookName,borrower,borrowTime,howLong, returned,destroyed,compensated);
    }
}
