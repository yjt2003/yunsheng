package com.yunsheng.bookController.utils;

import com.sun.mail.util.MailSSLSocketFactory;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.security.GeneralSecurityException;
import java.util.Properties;

public class SendEmail {
    public static void send(String Email,String captcha) throws MessagingException, GeneralSecurityException {
        String from = "2661236251@qq.com";
        String host = "smtp.qq.com";
        Properties properties = System.getProperties();
        properties.setProperty("mail.smtp.host",host);
        properties.setProperty("mail.smtp.auth","ture");
        properties.setProperty("mail.transport.protocol","smtp");
        properties.put("mail.smtp.ssl.protocols","TLSv1.2");
        MailSSLSocketFactory sf = new MailSSLSocketFactory();
        sf.setTrustAllHosts(true);
        properties.put("mail.smtp.ssl.enable","true");
        properties.put("mail.smtp.ssl.socketFactory",sf);
        Session session = Session.getDefaultInstance(properties, new Authenticator() {
            @Override
            public PasswordAuthentication getPasswordAuthentication(){
                return new PasswordAuthentication("2661236251@qq.com","mcrkicuoempoebcf");
            }
        });
        session.setDebug(true);
        Transport transport = session.getTransport();
        transport.connect(host,from,"mcrkicuoempoebcf");
        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(from));
        message.addRecipient(Message.RecipientType.TO,new InternetAddress(Email));
        message.setSubject("图书管理系统用户注册验证码");
        message.setText(captcha);
        transport.sendMessage(message, message.getAllRecipients());
        System.out.println("发送成功！");
    }
}
