package com.yunsheng.bookController.modules.common.servlet;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.yunsheng.bookController.modules.common.entity.Book;
import com.yunsheng.bookController.modules.common.entity.BorrowRecords;
import com.yunsheng.bookController.modules.common.entity.BorrowingBook;
import com.yunsheng.bookController.modules.common.util.Time;
import com.yunsheng.bookController.modules.register.entity.User;
import com.yunsheng.bookController.utils.DBUtil;
import com.yunsheng.bookController.utils.Json;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/borrow")
public class borrowServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=UTF-8");
        ServletContext sc = request.getServletContext();
        HttpSession session = request.getSession();
        //ArrayList<Book> cartArr = (ArrayList<Book>)session.getAttribute("cartArr");
        ArrayList<Book> cartArr = new ArrayList<Book>();
        Book book = new Book("c语言程序设计","曹睿","1000","2022007090","小明","2023-2-22","2023-3-22");
        cartArr.add(book);
        Json.sendDataArr(response,cartArr);
        //把已选书籍信息传给前端让前端布置
        //request.getRequestDispatcher("展示已选书籍").forward(request,response);
        ///////////////////展示选择的书/////////////////////
        ////////////////////确认借阅///////////////////////
        String jsonstr = Json.getJson(request);
        JSONObject jsonObj = JSON.parseObject(jsonstr);
        String method = jsonObj.getString("method");
        if(method.equals("confirm")) {              //确定借阅
            ///////////////前端传递书籍对象组/////////////////
            String jsonObject = Json.getJson(request);
            List<BorrowingBook> confirmArr = JSON.parseArray(jsonObject,BorrowingBook.class);
            User user = (User)session.getAttribute("user");
            ArrayList<BorrowRecords> records = (ArrayList<BorrowRecords>) sc.getAttribute("records");
            for (int i = 0; i < confirmArr.size(); i++) {
                user.setBookForReturn(user.getBookForReturn() + confirmArr.get(i).getBook().getName());
                BorrowRecords br = new BorrowRecords(confirmArr.get(i).getBook().getName(),user.getName(),
                        Time.getCurrentTime(),confirmArr.get(i).getHowLong(),false,false,false);
                records.add(br);
                try {
                    DBUtil.insertRecords(br);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
            sc.setAttribute("records",records);
            cartArr.removeAll(confirmArr);
            session.setAttribute("cartArr",cartArr);
            session.setAttribute("user",user);
        }
        if(method.equals("cancel")){
            String json = Json.getJson(request);
            JSONObject jsonObject = JSON.parseObject(jsonstr);
            String bookname = jsonObject.getString("name");
            for (int i = 0; i <cartArr.size() ; i++) {
                if(cartArr.get(i).getName().equals(bookname)){
                    cartArr.remove(i);
                }
            }
        }
    }
}
