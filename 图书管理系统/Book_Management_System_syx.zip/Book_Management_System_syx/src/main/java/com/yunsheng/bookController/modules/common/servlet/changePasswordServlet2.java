package com.yunsheng.bookController.modules.common.servlet;

import com.yunsheng.bookController.utils.DBUtil;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet(name = "changePasswordServlet2", value = "/changePassword2")
public class changePasswordServlet2 extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String newPassword = request.getParameter("newPassword");
        String passwordAgain = request.getParameter("passwordAgain");
        String account = (String)request.getAttribute("account");
        if(newPassword.equals(passwordAgain)){
            try {
                Connection conn = DBUtil.connectMysql();
                String sql = "update user set password = ? where account = ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1,newPassword);
                pstmt.setString(2,account);
                pstmt.executeUpdate();
                request.getRequestDispatcher("修改密码成功").forward(request,response);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }else {
            request.getRequestDispatcher("密码不一致").forward(request,response);
        }
    }
}
