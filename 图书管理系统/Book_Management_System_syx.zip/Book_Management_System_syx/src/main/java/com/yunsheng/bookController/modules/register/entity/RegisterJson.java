package com.yunsheng.bookController.modules.register.entity;

import com.alibaba.fastjson.annotation.JSONField;

public class RegisterJson {
    @JSONField(name = "method")
    String method;
    @JSONField(name = "stuID")
    String ID;
    @JSONField(name = "name")
    String name;
    @JSONField(name = "password")
    String password;
    @JSONField(name = "Email")
    String Email;
    @JSONField(name = "userCaptcha")
    String userCaptcha;

    public RegisterJson() {
    }

    public RegisterJson(String method, String ID, String name, String password, String email, String userCaptcha) {
        this.method = method;
        this.ID = ID;
        this.name = name;
        this.password = password;
        Email = email;
        this.userCaptcha = userCaptcha;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }



    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getUserCaptcha() {
        return userCaptcha;
    }

    public void setUserCaptcha(String userCaptcha) {
        this.userCaptcha = userCaptcha;
    }
}
