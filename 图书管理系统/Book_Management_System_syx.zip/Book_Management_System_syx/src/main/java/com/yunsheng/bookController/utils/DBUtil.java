package com.yunsheng.bookController.utils;

import com.alibaba.druid.pool.DruidDataSourceFactory;
import com.yunsheng.bookController.modules.common.entity.BorrowRecords;

import javax.sql.DataSource;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Properties;

public class DBUtil {
    public static Connection connectMysql() throws Exception {
        Properties properties = new Properties();
        InputStream is = DBUtil.class.getResourceAsStream("/mysql.properties");
        properties.load(is);
        DataSource dataSource = DruidDataSourceFactory.createDataSource(properties);
        Connection connection = dataSource.getConnection();
        return connection;
    }

    public static void updateBook(String bookName,String fieldName,String changeTo) throws Exception {
        Connection conn = connectMysql();
        String sql = "update book set ? = ? where name = ?";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setString(1,fieldName);
        pstmt.setString(2,changeTo);
        pstmt.setString(3,bookName);
        pstmt.executeUpdate();
        pstmt.close();
    }

    public static void insertRecords(BorrowRecords br) throws Exception {
        Connection conn = connectMysql();
        String sql = "insert into borrowrecords values (?,?,?,?,?,?,?)";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, br.getBookName());
        pstmt.setString(2,br.getBorrower());
        pstmt.setTimestamp(3,br.getBorrowTime());
        pstmt.setInt(4,br.getHowLong());
        pstmt.setString(5,"否");
        pstmt.setString(6,"否");
        pstmt.setString(7,"否");
        pstmt.executeUpdate();
        pstmt.close();
    }
}
