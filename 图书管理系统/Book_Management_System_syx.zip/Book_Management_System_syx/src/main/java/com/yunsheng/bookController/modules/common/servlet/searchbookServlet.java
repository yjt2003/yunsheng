package com.yunsheng.bookController.modules.common.servlet;

import com.yunsheng.bookController.modules.common.dao.CommonDaoImp;
import com.yunsheng.bookController.modules.common.entity.Book;
import com.yunsheng.bookController.modules.common.entity.BorrowRecords;
import com.yunsheng.bookController.modules.common.util.SearchBook;
import com.yunsheng.bookController.modules.register.entity.User;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet("/searchbook")
public class searchbookServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        try {
            ServletContext sc = request.getServletContext();
            ArrayList<Book> bookArr = CommonDaoImp.getBookAll();
            sc.setAttribute("bookArr",bookArr);
            ArrayList<BorrowRecords> records= new ArrayList<BorrowRecords>();
            sc.setAttribute("records",records);
            String userInput = request.getParameter("userInput");
            ArrayList<Book> searchArr = SearchBook.search(userInput,bookArr);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        String method = request.getParameter("method");
        if(method.equals("choose")){
            ServletContext sc = request.getServletContext();
            HttpSession session = request.getSession();
            ArrayList<Book> cartArr = (ArrayList) session.getAttribute("cartArr");
            if(cartArr == null){
                cartArr = new ArrayList<Book>();
            }
            String bookname = request.getParameter("bookname");
            User user = (User)session.getAttribute("user");
            for (Book book:cartArr) {
                if(bookname.equals(book.getName())){
                    request.getRequestDispatcher("该书已被选择").forward(request,response);
                    return;
                }
            }
            ArrayList<Book> bookArr = (ArrayList) sc.getAttribute("bookArr");
            for (Book b:bookArr) {
                if(b.getName().equals(bookname)){
                    if(bookname.matches(user.getBookForReturn())){
                        request.getRequestDispatcher("您已借阅该书").forward(request,response);
                        return;
                    }
                    cartArr.add(b);
                    session.setAttribute("cartArr",cartArr);
                    return;
                }
            }
        }
    }

}
