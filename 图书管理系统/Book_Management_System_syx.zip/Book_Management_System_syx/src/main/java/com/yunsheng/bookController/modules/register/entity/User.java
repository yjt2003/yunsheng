package com.yunsheng.bookController.modules.register.entity;

public class User {
    private String account;
    private String password;
    private String name;
    private String stuID;
    private String Email;
    private String bookForReturn;

    public User() {
    }

    public User(String account, String password, String name, String stuID, String email, String bookForReturn) {
        this.account = account;
        this.password = password;
        this.name = name;
        this.stuID = stuID;
        Email = email;
        this.bookForReturn = bookForReturn;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStuID() {
        return stuID;
    }

    public void setStuID(String stuID) {
        this.stuID = stuID;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getBookForReturn() {
        return bookForReturn;
    }

    public void setBookForReturn(String bookForReturn) {
        this.bookForReturn = bookForReturn;
    }
}
