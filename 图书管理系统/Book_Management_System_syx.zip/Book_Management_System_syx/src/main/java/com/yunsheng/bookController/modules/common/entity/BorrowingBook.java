package com.yunsheng.bookController.modules.common.entity;

public class BorrowingBook {
    private Book book;
    private int howLong;

    public BorrowingBook() {
    }

    public BorrowingBook(Book book, int howLong) {
        this.book = book;
        this.howLong = howLong;
    }

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    public int getHowLong() {
        return howLong;
    }

    public void setHowLong(int howLong) {
        this.howLong = howLong;
    }
}
