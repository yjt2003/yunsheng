package com.yunsheng.bookController.modules.register.servlet;

import com.yunsheng.bookController.utils.Json;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "registerSendStatusServlet", value = "/registerSendStatusServlet")
public class registerSendStatusServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int status = (int)request.getAttribute("status");
        Json.sendStatus(response,status);
    }
}
