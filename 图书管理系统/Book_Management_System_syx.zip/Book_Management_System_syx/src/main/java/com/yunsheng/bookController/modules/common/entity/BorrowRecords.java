package com.yunsheng.bookController.modules.common.entity;

import java.sql.Timestamp;

public class BorrowRecords {
    private String bookName;
    private String borrower;
    private Timestamp borrowTime;
    private int howLong;
    private boolean returned;
    private boolean destroyed;
    private boolean compensated;

    public BorrowRecords() {
    }

    public BorrowRecords(String bookName, String borrower, Timestamp borrowTime, int howLong, boolean returned, boolean destroyed, boolean compensated) {
        this.bookName = bookName;
        this.borrower = borrower;
        this.borrowTime = borrowTime;
        this.howLong = howLong;
        this.returned = returned;
        this.destroyed = destroyed;
        this.compensated = compensated;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getBorrower() {
        return borrower;
    }

    public void setBorrower(String borrower) {
        this.borrower = borrower;
    }

    public Timestamp getBorrowTime() {
        return borrowTime;
    }

    public void setBorrowTime(Timestamp borrowTime) {
        this.borrowTime = borrowTime;
    }

    public int getHowLong() {
        return howLong;
    }

    public void setHowLong(int howLong) {
        this.howLong = howLong;
    }

    public boolean isReturned() {
        return returned;
    }

    public void setReturned(boolean returned) {
        this.returned = returned;
    }

    public boolean isDestroyed() {
        return destroyed;
    }

    public void setDestroyed(boolean destroyed) {
        this.destroyed = destroyed;
    }

    public boolean isCompensated() {
        return compensated;
    }

    public void setCompensated(boolean compensated) {
        this.compensated = compensated;
    }

    @Override
    public String toString() {
        return "borrowRecords{" +
                "bookName='" + bookName + '\'' +
                ", borrower='" + borrower + '\'' +
                ", borrowTime=" + borrowTime +
                ", howLong=" + howLong +
                ", returned=" + returned +
                ", destroyed=" + destroyed +
                ", compensated=" + compensated +
                '}';
    }
}
