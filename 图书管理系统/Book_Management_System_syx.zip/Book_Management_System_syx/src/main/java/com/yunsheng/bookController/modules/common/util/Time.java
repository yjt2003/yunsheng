package com.yunsheng.bookController.modules.common.util;

import java.sql.Timestamp;

public class Time {
    public static Timestamp getCurrentTime(){
        return new Timestamp(System.currentTimeMillis());
    }
}
