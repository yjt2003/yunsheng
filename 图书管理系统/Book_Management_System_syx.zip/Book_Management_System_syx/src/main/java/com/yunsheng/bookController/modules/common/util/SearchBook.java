package com.yunsheng.bookController.modules.common.util;

import com.yunsheng.bookController.modules.common.entity.Book;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SearchBook {
    public static ArrayList<Book> search(String input,ArrayList<Book> bookArr){
        ArrayList<Book> searchArr = new ArrayList<Book>();
        Pattern pattern = Pattern.compile(input,Pattern.CASE_INSENSITIVE);
        for (int i = 0; i < bookArr.size(); i++) {
            Matcher matcher = pattern.matcher(bookArr.get(i).getName());
            if(matcher.find()){
                searchArr.add(bookArr.get(i));
            }
        }
        return searchArr;
    }
}
