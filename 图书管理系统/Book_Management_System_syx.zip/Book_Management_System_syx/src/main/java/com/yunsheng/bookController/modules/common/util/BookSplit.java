package com.yunsheng.bookController.modules.common.util;

import com.yunsheng.bookController.modules.register.entity.User;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BookSplit {
    public static List<String> getBookSplit(User user){
        Pattern pattern = Pattern.compile("《(.*?)》");
        Matcher matcher = pattern.matcher(user.getBookForReturn());
        List<String> bookList = new ArrayList<String>();
        while (matcher.find()){
            String book = matcher.group(1);
            bookList.add(book);
        }
        return bookList;
    }
}
