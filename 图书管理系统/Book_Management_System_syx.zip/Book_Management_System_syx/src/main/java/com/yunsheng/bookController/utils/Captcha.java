package com.yunsheng.bookController.utils;

import java.util.Random;

public class Captcha {
    public static String getCaptcha(){
        Random random = new Random();
        String sample = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String captcha = "";
        for (int i = 0; i < 5; i++) {
            int randnum = random.nextInt(58);
            captcha += sample.charAt(randnum);
        }
        return captcha;
    }
}
