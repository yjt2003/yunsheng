package com.yunsheng.bookController.modules.register.dao;

import com.yunsheng.bookController.utils.DBUtil;

import java.sql.*;

public class UserDaoImp implements UserDao{
    public ResultSet getResultSet(String ID) throws Exception {
        Connection conn = DBUtil.connectMysql();
        Statement st = conn.createStatement();
        String sql = "select stuID from user";
        ResultSet rs = st.executeQuery(sql);
        return rs;
    }
    @Override
    public boolean checkStuID(String ID) throws Exception {
        ResultSet rs = this.getResultSet(ID);
        return rs.getString("stuID") != null;
    }

    @Override
    public boolean checkName(String ID,String name) throws Exception {
        ResultSet rs = this.getResultSet(ID);
        return rs.getString("name").equals(name);
    }


    @Override
    public void addEmail(String ID, String Email) throws Exception {
        Connection conn = DBUtil.connectMysql();
        String sql = "update user set Email = ? where stuID = ?";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setString(1,Email);
        pstmt.setString(2,ID);
        pstmt.executeUpdate();
    }

    public boolean checkAccount(String ID) throws Exception {
        ResultSet rs = this.getResultSet(ID);
        String account = rs.getString("account");
        return account == null;
    }
}
