package com.yunsheng.bookController.modules.register.servlet;

import com.alibaba.fastjson.JSON;
import com.yunsheng.bookController.modules.register.dao.UserDaoImp;
import com.yunsheng.bookController.modules.register.entity.RegisterJson;
import com.yunsheng.bookController.utils.Captcha;
import com.yunsheng.bookController.utils.DBUtil;
import com.yunsheng.bookController.utils.Json;
import com.yunsheng.bookController.utils.SendEmail;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/register")
public class registerServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=UTF-8");
        HttpSession session = req.getSession();
        /*JSONObject jsonObject = Data.get(req);
        RegisterJson registerJson = JSON.parseObject(String.valueOf(jsonObject), RegisterJson.class);*/
        String json = Json.getJson(req);
        RegisterJson registerJson = JSON.parseObject(json, RegisterJson.class);
        System.out.println(registerJson);
        //JSONObject jsonObject = JSON.parseObject(json);
        /*RegisterJson registerJson = JSONObject.parseObject(json, RegisterJson.class);
        System.out.println(registerJson.toString());*/
        String method = registerJson.getMethod();
        String ID = registerJson.getID();
        String name = registerJson.getName();
        String password = registerJson.getPassword();
        String Email = registerJson.getEmail();
        String userCaptcha = registerJson.getUserCaptcha();
        String captcha = (String)session.getAttribute("captcha");
        if(method.equals("post")) {
            UserDaoImp userDao = new UserDaoImp();
            try {
                if (!userDao.checkStuID(ID)) {
                    //req.getRequestDispatcher("学生号错误").forward(req, resp);    /////////////////////////

                }else if (!userDao.checkName(ID, name)) {
                    Json.sendStatus(resp,0);
                }else if (!userDao.checkAccount(ID)) {
                    Json.sendStatus(resp,1);
                }else if (!password.matches("\\w{6,20}")) {
                    Json.sendStatus(resp,2);
                }else if(!Email.matches("[1-9]d{7,10}@qq.com")){
                    Json.sendStatus(resp,3);
                }else if (userCaptcha == null || userCaptcha.equals("")) {
                    Json.sendStatus(resp,4);
                }else if(!userCaptcha.equals(captcha)){
                    Json.sendStatus(resp,5);
                }
                Connection conn = DBUtil.connectMysql();
                String sql = "update user set account = (max(account) + 1) password = ? Email = ? where stuID = ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, password);
                pstmt.setString(2, Email);
                pstmt.setString(3, ID);
                pstmt.executeUpdate();
                String sql2 = "select account from user where stuID = ?";
                PreparedStatement pstmt2 = conn.prepareStatement(sql2);
                pstmt2.setString(1,ID);
                ResultSet rs = pstmt2.executeQuery();
                String userAccount = rs.getString("account");
                PrintWriter out = resp.getWriter();
                out.println("注册成功，您的账号为:"+userAccount);
            } catch (Exception e) {
                System.out.println("信息校验失败");
            }
        }else if(method.equals("get")) {
            String str = Captcha.getCaptcha();
            session.setAttribute("captcha", str);
            if (!Email.matches("[1-9]d{7,10}@qq.com")) {
                req.getRequestDispatcher("邮箱格式不合法").forward(req, resp);
            } else {
                try {
                    SendEmail.send(Email,captcha);
                } catch (Exception e) {
                    req.getRequestDispatcher("邮件发送失败").forward(req, resp);
                }
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req, resp);
    }
}
