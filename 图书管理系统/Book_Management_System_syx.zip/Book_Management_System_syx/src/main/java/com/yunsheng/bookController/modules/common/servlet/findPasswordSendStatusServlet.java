package com.yunsheng.bookController.modules.common.servlet;

import com.yunsheng.bookController.utils.Json;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "findPasswordSendStatusServlet", value = "/findPasswordSendStatusServlet")
public class findPasswordSendStatusServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        //int status = (int)session.getAttribute("status");
        //传输状态码
        Json.sendStatus(response,1);
    }
}
