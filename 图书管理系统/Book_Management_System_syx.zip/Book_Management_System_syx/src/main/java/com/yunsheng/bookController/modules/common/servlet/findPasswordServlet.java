package com.yunsheng.bookController.modules.common.servlet;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.yunsheng.bookController.utils.Captcha;
import com.yunsheng.bookController.utils.DBUtil;
import com.yunsheng.bookController.utils.Json;
import com.yunsheng.bookController.utils.SendEmail;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet(name = "findPasswordServlet", value = "/findPasswordServlet")
public class findPasswordServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String captcha = (String)session.getAttribute("captcha");
        String json = Json.getJson(request);
        System.out.println(json);
        JSONObject jsonObject = JSON.parseObject(json);
        System.out.println(jsonObject);
        String method = jsonObject.getString("method");
        String ID = jsonObject.getString("stuID");
        String name = jsonObject.getString("name");
        String newPassword = jsonObject.getString("newPassword");
        String email = jsonObject.getString("Email");
        String userCaptcha = jsonObject.getString("userCaptcha");
        if(method.equals("post")) {
            try {
                Connection conn = DBUtil.connectMysql();
                String sql = "select * from user where stuID = ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, ID);
                ResultSet rs = pstmt.executeQuery();
                if(rs.next()) {
                    String dataName = rs.getString("name");
                    String dataEmail = rs.getString("Email");
                    if(!name.equals(dataName)){
                        //状态码，姓名错误
                        session.setAttribute("status",0);
                        request.getRequestDispatcher("/findPasswordSendStatusServlet").forward(request,response);
                    }else if (!email.equals(dataEmail)){
                        //状态码，邮箱错误
                        session.setAttribute("status",1);
                        request.getRequestDispatcher("/findPasswordSendStatusServlet").forward(request,response);
                    }else if(!userCaptcha.equals(captcha)){
                        //状态码，验证码错误
                        session.setAttribute("status",2);
                        request.getRequestDispatcher("/findPasswordSendStatusServlet").forward(request,response);
                    }else {
                        String sql2 = "update user set password = ? where stuID = ?";
                        pstmt = conn.prepareStatement(sql2);
                        pstmt.setString(1,newPassword);
                        pstmt.setString(2,ID);
                        pstmt.executeUpdate();
                        //状态码，修改成功
                        session.setAttribute("status",3);
                        request.getRequestDispatcher("/findPasswordSendStatusServlet").forward(request,response);
                    }
                }else {
                    //学号不存在，返回一个状态码
                    session.setAttribute("status",4);
                    request.getRequestDispatcher("/findPasswordSendStatusServlet").forward(request,response);
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }else if(method.equals("get")) {
            try {
                Connection conn = DBUtil.connectMysql();
                String sql = "select * from user where Email = ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, email);
                ResultSet rs = pstmt.executeQuery();
                if(rs.next()){
                    String str = Captcha.getCaptcha();
                    session.setAttribute("captcha", str);
                    if (!email.matches("[1-9]d{7,10}@qq.com")) {
                        //状态码，邮箱格式不合法
                        request.setAttribute("status",5);
                        request.getRequestDispatcher("/findPasswordSendStatusServlet").forward(request,response);                    }else {
                        try {
                            SendEmail.send(email,captcha);
                        } catch (Exception e) {
                            //状态码，邮件发送失败
                            session.setAttribute("status",6);
                            request.getRequestDispatcher("/findPasswordSendStatusServlet").forward(request,response);                        }
                    }
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }
}
