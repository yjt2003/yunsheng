package com.yunsheng.bookController.utils;

import com.alibaba.fastjson.JSONObject;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class Data {
    /**
     * 获取前端发来的字节流，并转化成字符串,在转化成JSON
     *
     * @param request 请求数据流
     * @return 转化后的字符串
     */
    static public JSONObject get(HttpServletRequest request) {

        try {
            InputStreamReader inputStreamReader = new InputStreamReader(request.getInputStream(), StandardCharsets.UTF_8);
            StringBuilder str = new StringBuilder();
            int respInt = inputStreamReader.read();
            while (respInt != -1) {
                str.append((char) respInt);
                respInt = inputStreamReader.read();
            }
            String jsonString = String.valueOf(str);
            return JSONObject.parseObject(jsonString);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return JSONObject.parseObject(null);
    }
}

