package com.yunsheng.bookController.modules.common.dao;

import com.yunsheng.bookController.modules.common.entity.Book;
import com.yunsheng.bookController.modules.common.entity.BorrowRecords;

import java.sql.Timestamp;

public interface CommonDao {
    public Book getBook(String name) throws Exception;
    public BorrowRecords getRecordPackaged(String bookName, String borrower, Timestamp borrowTime, int howLong,
                                           boolean returned, boolean destroyed, boolean compensated);

}
