package com.yunsheng.bookController.modules.register.dao;

public interface UserDao {
    boolean checkStuID(String ID) throws Exception;

    public default boolean checkName(String ID,String name) throws Exception {
        return false;
    }

    void addEmail(String ID, String Email) throws Exception;
}
