package com.yunsheng.bookController.modules.common.servlet;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.yunsheng.bookController.modules.register.entity.User;
import com.yunsheng.bookController.utils.Captcha;
import com.yunsheng.bookController.utils.DBUtil;
import com.yunsheng.bookController.utils.Json;
import com.yunsheng.bookController.utils.SendEmail;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/changePassword")
public class changePasswordServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        User user = (User)session.getAttribute("user");
        String json = Json.getJson(req);
        JSONObject jsonObject = JSON.parseObject(json);
        String method = jsonObject.getString("method");  //需要登录模块在用户登录成功时把用户账号录入session
        String captcha = Captcha.getCaptcha();
        String account = user.getAccount();
        if(method.equals("post")) {
            try {
                Connection conn = DBUtil.connectMysql();
                String sql = "select Email from user where account = ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, account);
                ResultSet rs = pstmt.executeQuery();
                rs.next();
                String Email = rs.getString("Email");
                SendEmail.send(Email, captcha);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }else if(method.equals("get")) {
            String captchaForPassword = req.getParameter("captchaForPassword");
            if(captchaForPassword.equals(captcha)){
                req.setAttribute("account",account);
                req.getRequestDispatcher("/changePassword2").forward(req,resp);
            }else{
                req.getRequestDispatcher("验证码错误").forward(req, resp);
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req,resp);
    }
}
