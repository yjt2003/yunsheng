package com.yunsheng.bookController.modules.common.entity;

import com.alibaba.fastjson.annotation.JSONField;

public class Book {
    @JSONField(ordinal = 1)
    private String name;
    @JSONField(ordinal = 2)
    private String author;
    @JSONField(ordinal = 3)
    private String ISBN;
    @JSONField(ordinal = 4)
    private String readerID;
    @JSONField(ordinal = 5)
    private String readerName;
    @JSONField(ordinal = 6)
    private String borrowTime;
    @JSONField(ordinal = 7)
    private String returnTime;

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    public String getReaderID() {
        return readerID;
    }

    public void setReaderID(String readerID) {
        this.readerID = readerID;
    }

    public String getReaderName() {
        return readerName;
    }

    public void setReaderName(String readerName) {
        this.readerName = readerName;
    }



    public Book() {
    }

    public Book(String name, String author, String ISBN, String readerID, String readerName, String borrowTime, String returnTime) {
        this.name = name;
        this.author = author;
        this.ISBN = ISBN;
        this.readerID = readerID;
        this.readerName = readerName;
        this.borrowTime = borrowTime;
        this.returnTime = returnTime;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }


    public String getBorrowTime() {
        return borrowTime;
    }

    public void setBorrowTime(String borrowTime) {
        this.borrowTime = borrowTime;
    }

    public String getReturnTime() {
        return returnTime;
    }

    public void setReturnTime(String returnTime) {
        this.returnTime = returnTime;
    }
}



